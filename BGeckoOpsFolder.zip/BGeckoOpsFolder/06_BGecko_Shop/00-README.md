# BGecko Shop

**Purpose:** Sell mission-backed products without damaging trust.

**Core rules**
- Product pages are engineering docs: claims, specs, care, FAQs.
- Price from cost + margin + positioning; track contribution margin.
- Customer support is part of brand.

**Key artifacts**
- Launch checklist + product page template
- Pricing calculator (no invented numbers)
- Fulfillment/returns SOP + policy templates
- Customer service macros

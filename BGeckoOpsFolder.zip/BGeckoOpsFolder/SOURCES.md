# Sources (public pages visited)

- Home / mission: https://bgecko.org/
- Research overview: https://bgecko.org/bgecko-research/
- Mathematics (Institute content): https://bgecko.org/mathematics/
- Space category: https://bgecko.org/category/space/
- Coordination page + hierarchy PDF: https://bgecko.org/calendar/ and https://bgecko.org/wp-content/uploads/2025/11/bgecko_grouphierarchy.pdf
- About: https://bgecko.org/about/
- Gallery: https://bgecko.org/gallery/
- Life blog: https://bgecko.org/category/life-blog/
- Shop (password page): https://bgecko.myshopify.com/
